﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Risiko
{
    
    public enum NomiStati
    {
        Argentina,
        Brasile,
        Usa,
        Canada,
        Alaska,
        Groenlandia,
        Islanda,
        GranBretagna,
        NeoNazisti,
        Italia,
        Francia,
        Urrs,
        Giappone,
        Cina,
        India,
        NuovaZelanda,
        Australia,
        AfricaDelNord,
        Madagascar,
        AfricaDelSud,
        ArmataPinguini
    }
    
}
